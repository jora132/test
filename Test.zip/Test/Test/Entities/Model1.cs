using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Test.Entities
{
    public partial class Model1 : DbContext
    {
        private static Model1 context;
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Client> Client { get; set; }
        public virtual DbSet<Employer> Employer { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
        public static Model1 GetContext()
        {
            if (context == null)
                context = new Model1();
            return context;
        }
    }
}
