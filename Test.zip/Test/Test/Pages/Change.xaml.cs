﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Test.Entities;
using Test.Pages;

namespace Test.Pages
{
    /// <summary>
    /// Логика взаимодействия для Change.xaml
    /// </summary>
    public partial class Change : Page
    {
        Model1 db = Model1.GetContext();
        Client cl;
        public Change(int idSelected)
        {
            InitializeComponent();
            cl = db.Client.Where(a => a.id == idSelected).FirstOrDefault();
            tbName.Text = cl.Name;
            tbLastName.Text = cl.LastName;
            
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                cl.Name = tbName.Text.Trim();
                cl.LastName = tbLastName.Text.Trim();              
                db.Entry(cl).State = EntityState.Modified;
                db.SaveChanges();
                MessageBox.Show("Успешно сохранено!");
                NavigationService.Navigate(new Main());
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }
    }
}
