﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Test.Entities;

namespace Test.Pages
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
        public Main()
        {
            InitializeComponent();
            dg_Data.ItemsSource = Model1.GetContext().Client.ToList();
        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            
            Client cl1 = dg_Data.SelectedItem as Client;
            
            if (cl1 != null)
            {
                Client cl2 = Model1.GetContext().Client.Find(cl1.id);
                Model1.GetContext().Client.Remove(cl2);
                Model1.GetContext().SaveChanges();
                dg_Data.ItemsSource = Model1.GetContext().Client.ToList();
                MessageBox.Show("Строка удалена");
            }
            else
            {
                MessageBox.Show("Выбери строку");
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new addClient());
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Client cl = dg_Data.SelectedItem as Client;
            if (cl != null)
            {
                NavigationService.Navigate(new Change(cl.id));
            }
            

            

        }
    }
}
