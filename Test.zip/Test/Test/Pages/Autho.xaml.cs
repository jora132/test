﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Test.Entities;
using Test.Pages;

namespace Test.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        public Autho()
        {
            InitializeComponent();
        }

        private void btEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = tb_Login.Text.Trim();
            string password = pbPassword.Password.Trim();

           Employer emp = new Employer();
            emp = Model1.GetContext().Employer.Where(p => p.Login == login && p.Password == password).FirstOrDefault();
            int userCount = Model1.GetContext().Employer.Where(p => p.Login == login && p.Password == password).Count();

            if (userCount > 0)
            {
                MessageBox.Show("Вы вошли под: " + emp.name.ToString());
                NavigationService.Navigate(new Main());

            }
            else
            {
                MessageBox.Show("Вы ввели неверно логин или пароль!");
                
            }

        }
    }
}
